// يحوّل www/questions.js إلى www/questions.json (الملف اللي اللعبة بتحمّله أونلاين من GitHub)
// التشغيل: node scripts/build-questions.js
global.window = {};
require("../www/questions.js");
const fs = require("fs");
const q = window.BUNDLED_QUESTIONS;
fs.writeFileSync(__dirname + "/../www/questions.json", JSON.stringify(q));
console.log("تم: " + q.length + " سؤال");
